import React, { useState } from 'react';

export default function App() {
  const [file, setFile] = useState(null);
  const [summary, setSummary] = useState('');
  const [loading, setLoading] = useState(false);
  const [length, setLength] = useState('medium');

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) return alert('Please select a file first.');

    const formData = new FormData();
    formData.append('file', file);
    formData.append('length', length);

    setLoading(true);
    setSummary('');

    try {
      const res = await fetch('http://localhost:3000/api/summarize', {
        method: 'POST',
        body: formData
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Server error');
      setSummary(data.summary || '');
    } catch (err) {
      console.error(err);
      alert('Error processing file. ' + (err.message || ''));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f3f4f6', padding: 20 }}>
      <div style={{ width: '100%', maxWidth: 820, background: '#fff', padding: 24, borderRadius: 12, boxShadow: '0 10px 30px rgba(2,6,23,0.08)' }}>
        <h1 style={{ textAlign: 'center' }}>Document Summary Assistant</h1>

        <div style={{ border: '2px dashed #e5e7eb', padding: 20, borderRadius: 8, textAlign: 'center', marginTop: 16 }}>
          <p>Upload PDF or image</p>
          <input type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={handleFileChange} />
          {file && <p style={{ marginTop: 8, color: '#374151' }}>Selected: {file.name}</p>}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 16 }}>
          <label>Summary length:</label>
          <select value={length} onChange={(e) => setLength(e.target.value)}>
            <option value="short">Short</option>
            <option value="medium">Medium</option>
            <option value="long">Long</option>
          </select>
        </div>

        <button onClick={handleUpload} disabled={loading} style={{ width: '100%', marginTop: 16, padding: 12, background: '#0ea5a4', color: '#fff', borderRadius: 8 }}>
          {loading ? 'Processing...' : 'Generate Summary'}
        </button>

        {summary && (
          <div style={{ marginTop: 20, background: '#f8fafc', padding: 16, borderRadius: 8, whiteSpace: 'pre-wrap' }}>
            <h3>Summary</h3>
            <div>{summary}</div>
          </div>
        )}
      </div>
    </div>
  );
}
